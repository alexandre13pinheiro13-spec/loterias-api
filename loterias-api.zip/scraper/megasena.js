import axios from "axios";
import * as cheerio from "cheerio";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export async function fetchMegaSena() {
  const url = "https://loterias.caixa.gov.br/Paginas/Mega-Sena.aspx";
  const { data } = await axios.get(url);

  const $ = cheerio.load(data);

  const concurso = $("h2#wp_resultados h2").text().trim() || "";
  const dezenas = [];

  $("#ulDezenas > li").each((i, el) => dezenas.push($(el).text().trim()));

  const resultado = {
    concurso,
    dezenas,
    atualizado_em: new Date().toISOString()
  };

  const cacheFolder = path.join(__dirname, "..", "cache");
  if (!fs.existsSync(cacheFolder)) {
    fs.mkdirSync(cacheFolder);
  }

  fs.writeFileSync(
    path.join(cacheFolder, "megasena.json"),
    JSON.stringify(resultado, null, 2)
  );

  return resultado;
}