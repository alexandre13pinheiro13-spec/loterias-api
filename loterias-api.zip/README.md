# API de Loterias

API gratuita para consultar resultados da Mega-Sena.
